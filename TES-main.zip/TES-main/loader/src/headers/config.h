#pragma once

#define HTTP_SERVER "15.235.163.157"
#define HTTP_PORT 80

#define TFTP_SERVER "15.235.163.157"
